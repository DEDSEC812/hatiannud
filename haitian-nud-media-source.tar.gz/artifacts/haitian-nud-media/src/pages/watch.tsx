import { useEffect, useState } from "react";
import { useParams, Link } from "wouter";
import { useGetVideo, useRegisterView, useRequestDownload, useGetAdsConfig, useListComments, useCreateComment, useListVideos, getListCommentsQueryKey } from "@workspace/api-client-react";
import { useUser, SignInButton } from "@clerk/react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Skeleton } from "@/components/ui/skeleton";
import { formatDistanceToNow } from "date-fns";
import { fr } from "date-fns/locale";
import { Download, ThumbsUp, Share2, Star, MessageSquare, Play, AlertCircle, Send, Lock } from "lucide-react";
import { toast } from "sonner";
import { useQueryClient } from "@tanstack/react-query";
import { Badge } from "@/components/ui/badge";

const TELEGRAM_LINKS = [
  { label: "Groupe 1", url: "https://t.me/dg_haitiannud" },
  { label: "Groupe 2", url: "https://t.me/+UXtFEcF2Dw8zNGYx" },
  { label: "Canal 1", url: "https://t.me/hatiannud_canal" },
  { label: "Canal 2", url: "https://t.me/haiti_annud" },
];

function VipGate() {
  return (
    <div className="absolute inset-0 z-30 flex flex-col items-center justify-center bg-black/90 rounded-xl px-6">
      <div className="w-14 h-14 rounded-full bg-yellow-500/20 flex items-center justify-center mb-4">
        <Lock className="h-7 w-7 text-yellow-400" />
      </div>
      <h3 className="text-xl font-bold text-white mb-2">Contenu VIP</h3>
      <p className="text-white/70 text-sm text-center mb-6 max-w-xs">
        Cette vidéo est réservée aux membres VIP. Rejoignez notre Telegram pour y accéder dès maintenant.
      </p>
      <div className="flex flex-wrap gap-2 justify-center">
        {TELEGRAM_LINKS.map((link) => (
          <a
            key={link.url}
            href={link.url}
            target="_blank"
            rel="noopener noreferrer"
          >
            <Button size="sm" className="bg-primary hover:bg-primary/90 text-white gap-2">
              <Send className="h-3.5 w-3.5" /> {link.label}
            </Button>
          </a>
        ))}
      </div>
    </div>
  );
}

export function Watch() {
  const { id } = useParams<{ id: string }>();
  const { isSignedIn, user } = useUser();
  const queryClient = useQueryClient();
  const [commentBody, setCommentBody] = useState("");
  const [anonymous, setAnonymous] = useState(false);
  const [showAd, setShowAd] = useState(false);

  const { data: video, isLoading: isLoadingVideo } = useGetVideo(id!, { query: { enabled: !!id } });
  const { data: adsConfig } = useGetAdsConfig(id ? { videoId: id } : undefined);
  const { data: comments, isLoading: isLoadingComments } = useListComments(id!, { query: { enabled: !!id } });
  const { data: relatedVideos, isLoading: isLoadingRelated } = useListVideos({ category: video?.category }, { query: { enabled: !!video?.category } });

  const registerViewMutation = useRegisterView();
  const requestDownloadMutation = useRequestDownload();
  const createCommentMutation = useCreateComment();

  useEffect(() => {
    if (id) {
      registerViewMutation.mutate({ id }).catch(console.error);
    }
  }, [id]);

  useEffect(() => {
    if (id && video) {
      import("@/lib/local-store").then(({ pushWatchHistory }) =>
        pushWatchHistory({ id, title: video.title, thumbnailUrl: video.thumbnailUrl }),
      );
    }
  }, [id, video?.title, video?.thumbnailUrl]);

  useEffect(() => {
    if (adsConfig?.preroll) {
      setShowAd(true);
      const timer = setTimeout(() => setShowAd(false), 5000);
      return () => clearTimeout(timer);
    }
  }, [adsConfig, id]);

  const handleDownload = async () => {
    if (!id) return;
    if (!isSignedIn) {
      toast.error("Connectez-vous pour télécharger");
      return;
    }
    if (video?.isVip) {
      toast.error("Vidéo VIP — Rejoignez notre Telegram pour accéder au téléchargement.");
      return;
    }
    try {
      const res = await requestDownloadMutation.mutateAsync({ id });
      toast.success(`Téléchargement lancé. ${res.remaining} téléchargements restants aujourd'hui.`);
      window.open(res.url, "_blank");
    } catch (e: any) {
      toast.error(e?.message || "Limite atteinte. Revenez demain ou rejoignez Telegram VIP.");
    }
  };

  const handleShare = async () => {
    const url = window.location.href;
    if (navigator.share) {
      try {
        await navigator.share({ title: video?.title || "Haïtien Nud Média", url });
      } catch { /* cancelled */ }
    } else {
      try {
        await navigator.clipboard.writeText(url);
        toast.success("Lien copié !");
      } catch {
        toast.error("Impossible de partager");
      }
    }
  };

  const handleComment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!id || !commentBody.trim() || !isSignedIn) return;
    try {
      await createCommentMutation.mutateAsync({
        id,
        data: { body: commentBody, anonymous },
      });
      setCommentBody("");
      toast.success("Commentaire ajouté");
      queryClient.invalidateQueries({ queryKey: getListCommentsQueryKey(id) });
    } catch {
      toast.error("Erreur lors de l'ajout du commentaire");
    }
  };

  if (isLoadingVideo) {
    return (
      <div className="container mx-auto px-4 py-6 max-w-7xl">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 space-y-4">
            <Skeleton className="w-full aspect-video rounded-xl" />
            <Skeleton className="w-3/4 h-8" />
            <Skeleton className="w-1/2 h-4" />
          </div>
          <div className="hidden lg:block space-y-4">
            <Skeleton className="w-full h-8" />
            <Skeleton className="w-full aspect-video rounded-xl" />
            <Skeleton className="w-full aspect-video rounded-xl" />
          </div>
        </div>
      </div>
    );
  }

  if (!video) {
    return (
      <div className="container mx-auto px-4 py-24 text-center">
        <AlertCircle className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
        <h2 className="text-2xl font-serif font-bold mb-2">Vidéo non trouvée</h2>
        <p className="text-muted-foreground mb-6">Cette vidéo n'existe pas ou a été supprimée.</p>
        <Link href="/"><Button>Retour à l'accueil</Button></Link>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-6 max-w-7xl">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Main Content */}
        <div className="lg:col-span-2">
          {/* Player */}
          <div className="relative w-full aspect-video bg-black rounded-xl overflow-hidden shadow-2xl mb-4 group">
            {/* VIP gate overlay */}
            {video.isVip && <VipGate />}

            {showAd && !video.isVip ? (
              <div className="absolute inset-0 bg-zinc-900 flex flex-col items-center justify-center z-20">
                <span className="text-xs text-muted-foreground uppercase tracking-widest mb-2">Publicité</span>
                {adsConfig?.adToken ? (
                  <div className="text-primary font-bold">Ad Token: {adsConfig.adToken}</div>
                ) : (
                  <div className="w-32 h-8 bg-zinc-800 animate-pulse rounded"></div>
                )}
                <div className="absolute bottom-4 right-4 text-xs text-white/50">La vidéo commence dans quelques secondes...</div>
              </div>
            ) : null}

            <img src={video.thumbnailUrl || '/logo.jpg'} alt={video.title} className="w-full h-full object-cover opacity-50" />
            {!video.isVip && (
              <div className="absolute inset-0 flex items-center justify-center">
                <Button size="icon" className="w-16 h-16 rounded-full bg-primary/90 text-white hover:bg-primary hover:scale-110 transition-all shadow-[0_0_30px_rgba(30,94,255,0.5)]">
                  <Play className="h-8 w-8 ml-1" fill="currentColor" />
                </Button>
              </div>
            )}

            {/* Fake Controls (non-VIP only) */}
            {!video.isVip && (
              <div className="absolute bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-black/80 to-transparent opacity-0 group-hover:opacity-100 transition-opacity">
                <div className="w-full h-1 bg-white/20 rounded-full mb-4 overflow-hidden">
                  <div className="w-1/3 h-full bg-primary relative">
                    <div className="absolute right-0 top-1/2 -translate-y-1/2 w-3 h-3 bg-white rounded-full shadow"></div>
                  </div>
                </div>
                <div className="flex items-center justify-between text-white">
                  <div className="flex items-center gap-4">
                    <Play className="h-5 w-5 fill-current cursor-pointer" />
                    <span className="text-sm font-medium">0:00 / {Math.floor(video.durationSec / 60)}:{(video.durationSec % 60).toString().padStart(2, '0')}</span>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Info */}
          <div className="mb-6">
            <div className="flex flex-wrap items-start justify-between gap-4 mb-4">
              <div>
                <div className="flex items-center gap-2 mb-2">
                  <Badge variant="secondary" className="bg-accent text-accent-foreground border-border">{video.category}</Badge>
                  {video.isVip && (
                    <Badge variant="secondary" className="bg-gradient-to-r from-yellow-500 to-orange-400 text-white border-0">
                      <Star className="h-3 w-3 mr-1 fill-current" /> VIP Telegram
                    </Badge>
                  )}
                </div>
                <h1 className="text-2xl md:text-3xl font-serif font-bold text-foreground mb-2 leading-tight">{video.title}</h1>
                <div className="flex items-center text-sm text-muted-foreground gap-2">
                  <span>{video.views.toLocaleString()} vues</span>
                  <span className="w-1 h-1 rounded-full bg-muted-foreground/50"></span>
                  <span>{formatDistanceToNow(new Date(video.createdAt), { addSuffix: true, locale: fr })}</span>
                </div>
              </div>

              <div className="flex flex-wrap items-center gap-2">
                <Button variant="secondary" className="rounded-full bg-accent hover:bg-accent/80">
                  <ThumbsUp className="h-4 w-4 mr-2" /> J'aime
                </Button>
                <Button variant="secondary" onClick={handleShare} className="rounded-full bg-accent hover:bg-accent/80">
                  <Share2 className="h-4 w-4 mr-2" /> Partager
                </Button>
                {!video.isVip && (
                  <Button
                    onClick={handleDownload}
                    disabled={requestDownloadMutation.isPending}
                    className="rounded-full bg-primary hover:bg-primary/90 text-white shadow-[0_0_15px_rgba(30,94,255,0.3)]"
                  >
                    <Download className="h-4 w-4 mr-2" />
                    {requestDownloadMutation.isPending ? "..." : "Télécharger"}
                  </Button>
                )}
              </div>
            </div>

            <div className="p-4 bg-card border border-border rounded-xl">
              <p className="text-sm whitespace-pre-wrap">{video.description}</p>
            </div>

            {/* Telegram CTA for VIP */}
            {video.isVip && (
              <div className="mt-4 p-5 bg-gradient-to-r from-yellow-500/10 to-orange-500/10 border border-yellow-500/30 rounded-xl">
                <h3 className="font-bold mb-1 flex items-center gap-2">
                  <Send className="h-4 w-4 text-yellow-500" />
                  Rejoignez Telegram pour voir cette vidéo
                </h3>
                <p className="text-sm text-muted-foreground mb-4">Contenu VIP disponible sur nos groupes et canaux Telegram.</p>
                <div className="flex flex-wrap gap-2">
                  {TELEGRAM_LINKS.map((link) => (
                    <a key={link.url} href={link.url} target="_blank" rel="noopener noreferrer">
                      <Button size="sm" className="bg-yellow-500 hover:bg-yellow-600 text-black font-semibold gap-1.5">
                        <Send className="h-3.5 w-3.5" /> {link.label}
                      </Button>
                    </a>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Comments */}
          <div className="mt-8 pt-8 border-t border-border">
            <h3 className="text-xl font-serif font-bold mb-6 flex items-center gap-2">
              <MessageSquare className="h-5 w-5 text-primary" />
              Commentaires ({comments?.length || 0})
            </h3>

            {isSignedIn ? (
              <form onSubmit={handleComment} className="mb-8 bg-card p-4 rounded-xl border border-border">
                <div className="flex gap-4">
                  <Avatar className="h-10 w-10 shrink-0">
                    <AvatarImage src={user?.imageUrl} />
                    <AvatarFallback>{user?.firstName?.charAt(0) || "U"}</AvatarFallback>
                  </Avatar>
                  <div className="flex-1">
                    <Textarea
                      placeholder="Ajouter un commentaire..."
                      className="min-h-[80px] bg-background border-border resize-none focus-visible:ring-primary mb-3"
                      value={commentBody}
                      onChange={(e) => setCommentBody(e.target.value)}
                    />
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <Switch id="anonymous" checked={anonymous} onCheckedChange={setAnonymous} />
                        <Label htmlFor="anonymous" className="text-sm text-muted-foreground cursor-pointer">
                          Poster en anonyme
                        </Label>
                      </div>
                      <Button type="submit" disabled={!commentBody.trim() || createCommentMutation.isPending}>
                        Commenter
                      </Button>
                    </div>
                  </div>
                </div>
              </form>
            ) : (
              <div className="mb-8 p-6 bg-card border border-border rounded-xl text-center">
                <p className="text-muted-foreground mb-4">Connectez-vous pour participer à la discussion.</p>
                <SignInButton mode="modal">
                  <Button variant="outline">Connexion</Button>
                </SignInButton>
              </div>
            )}

            <div className="space-y-6">
              {isLoadingComments ? (
                Array.from({ length: 3 }).map((_, i) => (
                  <div key={i} className="flex gap-4">
                    <Skeleton className="w-10 h-10 rounded-full" />
                    <div className="flex-1 space-y-2">
                      <Skeleton className="w-32 h-4" />
                      <Skeleton className="w-full h-4" />
                      <Skeleton className="w-2/3 h-4" />
                    </div>
                  </div>
                ))
              ) : comments && comments.length > 0 ? (
                comments.map((comment) => (
                  <div key={comment.id} className="flex gap-4">
                    <Avatar className="h-10 w-10 shrink-0">
                      <AvatarFallback className="bg-primary/10 text-primary">
                        {comment.displayName.charAt(0).toUpperCase()}
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <div className="flex items-baseline gap-2 mb-1">
                        <span className="font-semibold text-sm">
                          {comment.anonymous ? "Anonyme" : comment.displayName}
                        </span>
                        <span className="text-xs text-muted-foreground">
                          {formatDistanceToNow(new Date(comment.createdAt), { addSuffix: true, locale: fr })}
                        </span>
                      </div>
                      <p className="text-sm text-foreground/90">{comment.body}</p>
                    </div>
                  </div>
                ))
              ) : (
                <p className="text-muted-foreground text-center py-8">Soyez le premier à commenter.</p>
              )}
            </div>
          </div>
        </div>

        {/* Sidebar Related */}
        <div className="lg:col-span-1">
          <h3 className="font-serif font-bold text-lg mb-4">Dans la même catégorie</h3>
          <div className="flex flex-col gap-4">
            {isLoadingRelated ? (
              Array.from({ length: 5 }).map((_, i) => (
                <div key={i} className="flex gap-3">
                  <Skeleton className="w-40 aspect-video rounded-lg shrink-0" />
                  <div className="flex-1 space-y-2 py-1">
                    <Skeleton className="w-full h-4" />
                    <Skeleton className="w-2/3 h-3" />
                  </div>
                </div>
              ))
            ) : relatedVideos && relatedVideos.length > 0 ? (
              relatedVideos.filter(v => v.id !== id).map(vid => (
                <Link key={vid.id} href={`/watch/${vid.id}`} className="flex gap-3 group">
                  <div className="relative w-40 aspect-video rounded-lg overflow-hidden shrink-0 bg-muted">
                    <img src={vid.thumbnailUrl || '/logo.jpg'} alt={vid.title} className="w-full h-full object-cover transition-transform group-hover:scale-105" />
                    {vid.isVip && (
                      <div className="absolute top-1 left-1">
                        <span className="bg-yellow-500 text-black text-[9px] font-bold px-1.5 py-0.5 rounded">VIP</span>
                      </div>
                    )}
                    <div className="absolute bottom-1 right-1 px-1 bg-black/80 text-[10px] text-white rounded">
                      {Math.floor(vid.durationSec / 60)}:{(vid.durationSec % 60).toString().padStart(2, '0')}
                    </div>
                  </div>
                  <div className="flex-1 min-w-0 py-1">
                    <h4 className="font-medium text-sm line-clamp-2 leading-tight group-hover:text-primary transition-colors">
                      {vid.title}
                    </h4>
                    <div className="text-xs text-muted-foreground mt-1">
                      {vid.views.toLocaleString()} vues
                    </div>
                  </div>
                </Link>
              ))
            ) : (
              <p className="text-sm text-muted-foreground">Aucune vidéo similaire.</p>
            )}
          </div>

          {/* Telegram community box */}
          <div className="mt-8 p-4 bg-card border border-border rounded-xl">
            <h4 className="font-semibold mb-3 flex items-center gap-2 text-sm">
              <Send className="h-4 w-4 text-primary" /> Communauté Telegram
            </h4>
            <div className="space-y-2">
              {TELEGRAM_LINKS.map((link) => (
                <a key={link.url} href={link.url} target="_blank" rel="noopener noreferrer"
                  className="flex items-center justify-between text-xs py-2 px-3 rounded-lg border border-border hover:border-primary/40 hover:bg-primary/5 transition-colors">
                  <span className="text-muted-foreground">{link.label}</span>
                  <span className="text-primary font-medium">Rejoindre →</span>
                </a>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
